<?php

	ini_set('memory_limit', '512M'); // or '1G'
	set_time_limit(0); // prevent timeouts

	require_once('upload.php');
	require_once('optimize.php');