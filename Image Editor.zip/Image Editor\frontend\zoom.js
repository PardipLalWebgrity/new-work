    let scale = 1,
    panning = false,
    pointX = 0,
    pointY = 0,
    start = { x: 0, y: 0 },
    zoom = document.getElementById("zoom");

    zoom.onmousedown = mousedown;
    zoom.onmouseup = mouseup;
    zoom.onmousemove = mousemove;
    zoom.onwheel = wheel;

    function wheel(e){
        e.preventDefault();
        var xs = (e.clientX-IMG.zoomOuterRect.x - pointX) / scale,
            ys = (e.clientY-IMG.zoomOuterRect.y - pointY) / scale,
            delta = (e.wheelDelta ? e.wheelDelta : -e.deltaY);
        (delta > 0) ? (scale *= 1.1) : (scale /= 1.1);
        pointX = (e.clientX-IMG.zoomOuterRect.x) - xs * scale;
        pointY = (e.clientY-IMG.zoomOuterRect.y) - ys * scale;

        setTransform();
    }

    function mousedown(e) {
        e.preventDefault();
        start = { x: e.clientX - pointX, y: e.clientY - pointY };
        panning = true;
    }

    function mousemove(e) {
        e.preventDefault();
        if (!panning) {
          return;
        }
        pointX = (e.clientX - start.x);
        pointY = (e.clientY - start.y);
        setTransform();
    }

    function mouseup(e) {
        panning = false;
    }

    function setTransform() {
        zoom.style.transform = "translate(" + pointX + "px, " + pointY + "px) scale(" + scale + ")";
    }

    // Function to zoom to a specific scale and center
    function zoomTo() {
        let rect = zoom.getBoundingClientRect();
        const zoomParentWidth = zoom.parentElement.offsetWidth;
        let zoomScaleWidth = rect.width*scale;
        console.log();

        while(zoomScaleWidth > zoomParentWidth){
            zoomScaleWidth = rect.width*scale;
            scale -= 0.1;
        }
        
        pointX = 0;
        pointY = 0;
        setTransform();
    }
    zoomTo();