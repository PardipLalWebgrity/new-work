const IMG = {
	id: {},
	imgData: new FormData(),
	zoomOuterRect: null,

	collectElements: function () {
		const els = document.querySelectorAll('[data-id]');
		els.forEach((el) => {
			IMG.id[el.dataset.id] = el;
		})
	},


	

	// Events
	events: function () {
		IMG.id.uploadImagoCanvas.addEventListener('change', IMG.userUploadImages);
		IMG.id.imagoImages.addEventListener('click', IMG.imagoImageItemClicked);
		IMG.id.downloadAll.addEventListener('click', IMG.downloadAllOptimizedImages);
		IMG.id.imagoImgCropVisible.addEventListener('change', IMG.imagoImgCropVisibleChange)

	},

	imagoImageItemClicked: function(e){
		const actionBtn = e.target.closest('[data-action]');
		if(!actionBtn) return;
		const action = actionBtn.dataset.action;
		if(action == 'editimg') IMG.editImagoImage(e);
		if(action == 'deleteimg') IMG.deleteImagoImage(e);
		
	},

	editImagoImage: function(e){
		const liEl = e.target.closest('.imago_image');
		if(!liEl) return;
		IMG.id.imagoImgviewerImg.src = liEl.dataset.src;
		IMG.id.imagoImgviewerImg.setAttribute('data-index', liEl.dataset.index);
	},

	deleteImagoImage: function(e){
		const liEl = e.target.closest('.imago_image');
		if(!liEl) return;
		liEl.remove();
	},

	userUploadImages: function (e) {
		const imgs = IMG.id.uploadImagoCanvas.files;
		let html = '';
		IMG.imgData.append('quality', IMG.id.imagoImgQuality.checked?35:100);
		[...imgs].forEach((img, i) => {
			IMG.imgData.append('images[]', img);					
			const imageURL = URL.createObjectURL(img);
			html += `
				<li class="imago_image" data-name="${img.name}" data-index="${i}" data-src="${imageURL}">
					<img class="imago_image_img" src="${imageURL}" alt="${img.name}">
					<button data-action="editimg"><i class="fa-solid fa-pen"></i></button>
					<button data-action="deleteimg"><i class="fa-solid fa-trash"></i></button>
					<button data-action="downloadimg"><i class="fa-solid fa-download"></i></button>
				</li>
			`;
			// URL.revokeObjectURL(imageURL);
		})
		IMG.id.imagoImages.insertAdjacentHTML('beforeend', html);		
	},

	downloadAllOptimizedImages: async function(){

		const resize = [];
		[...IMG.id.imagoImages.children].forEach((liEl)=>{
			resize.push({
				name: liEl.dataset.name,
				x: liEl.dataset.x,
				y: liEl.dataset.y,				
			})
		})

		IMG.imgData.append('quality', IMG.id.imagoImgQuality.checked?35:100);		
		IMG.imgData.append('resize', JSON.stringify(resize));		

		const res = await fetch("/backend/index.php", {
        method: "POST",
        body: IMG.imgData
    });

    const text = await res.text();
    console.log(text);
	},

	imagoImgCropVisibleChange: function(){
		IMG.id.zoomOuter.classList.toggle('show');
	},

	updateImageXYAsAttribute: function(){
		const index = IMG.id.imagoImgviewerImg?.dataset.index;
		if(!index) return;
		const translateCSS = window.getComputedStyle(IMG.id.imagoImgviewerImg.parentElement)['transform'].split(',');
		const translateX = translateCSS.at(-2);
		const translateY = translateCSS.at(-1);
		const indexLiEl = IMG.id.imagoImages.querySelector(`[data-index="${index}"]`)
		indexLiEl.setAttribute('data-x', translateX.trim());
		indexLiEl.setAttribute('data-y', translateY.trim());		
	},




	// Utility
	blobUrlToBinary: async function (blobUrl) {
		// Fetch the blob data from the blob URL
		const response = await fetch(blobUrl);
		const blob = await response.blob();

		// Convert blob to ArrayBuffer (binary data)
		const arrayBuffer = await blob.arrayBuffer();

		console.log(arrayBuffer); // binary data
		return arrayBuffer;
	},

	init: function () {
		IMG.collectElements();
		IMG.events();
		IMG.zoomOuterRect = IMG.id.zoomOuter.getBoundingClientRect();
	},

}



window.addEventListener('load', IMG.init);