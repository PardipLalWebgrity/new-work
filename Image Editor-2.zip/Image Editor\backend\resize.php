<?php

class Resize
{
	public function __construct()
	{
		$this->collectUnOptimizeFolder();
	}

	public function collectUnOptimizeFolder() {

		$resizeData = json_decode($_POST['resize']);

		// Get all files in the current directory
		$folders = scandir('uploads/');
		$i = 0;
		foreach ($folders as $singleFolder) {

			// skip dots folder
			if ($i == 0 || $i == 1) {
				$i++;
				continue;
			}

			// collect unoptimized folder
			$folderImages = scandir('uploads/' . $singleFolder);
			$unOptimizedFolders = [];
			foreach ($folderImages as $file) {
				if (substr($file, -4) !== '.zip') {
					array_push($unOptimizedFolders, $singleFolder);
				}
			}

			$unOptimizedFolders = array_unique($unOptimizedFolders);

			foreach ($unOptimizedFolders as $unOptimizedFolder) {
				$files = scandir('uploads/' . $unOptimizedFolder);
				foreach ($files as $file) {
					if (in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'gif'])) {
						$destination = 'uploads/' . $unOptimizedFolder . '/optimize/' . basename($file);
						
						foreach($resizeData as $imgData) {

						}
						$this->resizeImageWithOffset($unOptimizedFolder . '/' . $file, $destination, 50, 50, 50, 60);						
					}
				}
			}

			$i++;
		}
	}


	public function resizeImageWithOffset($sourcePath, $destPath, $targetWidth, $targetHeight, $offsetX = 0, $offsetY = 0) {
		// Get the original image information (type, width, height)
		$imageInfo = getimagesize('uploads/'.$sourcePath);

		// Extract original width and height
		$originalWidth  = $imageInfo[0];
		$originalHeight = $imageInfo[1];

		// Extract image type (1 = GIF, 2 = JPG, 3 = PNG)
		$imageType = $imageInfo[2];

		// Create a GD image resource from the source based on image type
		switch ($imageType) {
			case IMAGETYPE_JPEG:
				$sourceImage = imagecreatefromjpeg('uploads/'.$sourcePath);
				break;

			case IMAGETYPE_PNG:
				$sourceImage = imagecreatefrompng('uploads/'.$sourcePath);
				break;

			case IMAGETYPE_GIF:
				$sourceImage = imagecreatefromgif('uploads/'.$sourcePath);
				break;

			default:
				return false; // Unsupported image type
		}

		// Create a blank canvas for final resized image
		$finalImage = imagecreatetruecolor($targetWidth, $targetHeight);

		// Enable PNG transparency (only needed for PNG)
		imagealphablending($finalImage, false);
		imagesavealpha($finalImage, true);

		// Copy & resize using source offset + target size
		imagecopyresampled(
			$finalImage,      // destination image
			$sourceImage,     // source image
			0,
			0,             // destination x, y (always 0,0)
			$offsetX,         // source x offset
			$offsetY,         // source y offset
			$targetWidth,     // destination width
			$targetHeight,    // destination height
			$targetWidth,     // source width to copy
			$targetHeight     // source height to copy
		);

		// Save the final image based on original type
		switch ($imageType) {
			case IMAGETYPE_JPEG:
				imagejpeg($finalImage, $destPath, 90); // 90 = quality
				break;

			case IMAGETYPE_PNG:
				imagepng($finalImage, $destPath);
				break;

			case IMAGETYPE_GIF:
				imagegif($finalImage, $destPath);
				break;
		}

		// Free memory
		imagedestroy($sourceImage);
		imagedestroy($finalImage);

		// Return final path
		return $destPath;
	}
}

new Resize();
