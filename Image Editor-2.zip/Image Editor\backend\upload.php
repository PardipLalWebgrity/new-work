<?php

class Upload
{
	
	public function __construct() {
		$this->saveImagesToFolder();
	}

	public function saveImagesToFolder() {
		
		// create directory if not exists
		$basePath = "uploads/";
		$folderName = uniqid("img_", true);  // example: img_673a8f64e9deb5.1234
		$fullPath = $basePath . $folderName;
		if (!file_exists($fullPath)) {
				mkdir($fullPath, 0777, true);
				mkdir($fullPath.'/'.'optimize', 0777, true);
				mkdir($fullPath.'/'.'resize', 0777, true);
		}

		// Upload images
		$files = $_FILES["images"];
		$i = 0;
		foreach($files['name'] as $fileName) {
			$fileName = basename($files['name'][$i]);
			$targetFile = $fullPath .'/'. $fileName;
			$tmp_name = $files['tmp_name'][$i];
			move_uploaded_file($tmp_name, $targetFile);			
			$i++;
		}
		
	}
}

new Upload();
