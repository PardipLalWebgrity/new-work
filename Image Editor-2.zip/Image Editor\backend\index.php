<?php

	// ini_set('memory_limit', '512M'); // or '1G'
	// set_time_limit(0); // prevent timeouts

	require_once('upload.php');
	if($_POST['quality'] == 35) require_once('optimize.php');
	if($_POST['resize']) require_once('resize.php');