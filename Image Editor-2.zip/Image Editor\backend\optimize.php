<?php

	class Optimize {
		
		public function __construct() {
			$this->collectUnOptimizeFolder();
		}

		public function collectUnOptimizeFolder(){
			// Get all files in the current directory
			$folders = scandir('uploads/');
			$i = 0;
			foreach($folders as $singleFolder) {

				// skip dots folder
				if($i == 0 || $i == 1) {
					$i++;
					continue;					
				}

				// collect unoptimized folder
				$folderImages = scandir('uploads/'.$singleFolder);				
				$unOptimizedFolders = [];
				foreach ($folderImages as $file) {
						if (substr($file, -4) !== '.zip') {
								array_push($unOptimizedFolders, $singleFolder);
						}
				}
				$unOptimizedFolders = array_unique($unOptimizedFolders);

				foreach($unOptimizedFolders as $unOptimizedFolder) {
					$files = scandir('uploads/'.$unOptimizedFolder);
					foreach ($files as $file) {							
							if (in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'gif'])) {
									$destination = 'uploads/'.$unOptimizedFolder.'/optimize/' . basename($file); // Set the destination path in the 'result' folder
									$this->optimize_image($unOptimizedFolder.'/'.$file, $destination, $_POST['quality']); // Optimize the image									
							}
					}
				}
				
				
				
				$i++;
			}
		}
		
		public function optimize_image($source, $destination, $quality = 35) {
			echo $quality;
				// Get image details
				$image_info = getimagesize('uploads/'.$source);
				$image_type = $image_info[2];

				// Check for valid image type
				if ($image_type == IMAGETYPE_JPEG) {

						// Load JPEG image
						$image = imagecreatefromjpeg('uploads/'.$source);

						// Save compressed image						
						imagejpeg($image, $destination, $quality);

						// Free memory
						imagedestroy($image);
				} elseif ($image_type == IMAGETYPE_PNG) {
						// Load PNG image
						$image = imagecreatefrompng('uploads/'.$source);

						// Save compressed image
						imagepng($image, $destination, 9);  // PNG compression (0-9)

						// Free memory
						imagedestroy($image);
				} elseif ($image_type == IMAGETYPE_GIF) {
						// Load GIF image
						$image = imagecreatefromgif('uploads/'.$source);

						// Save compressed image
						imagegif($image, $destination);

						// Free memory
						imagedestroy($image);
				} else {
						echo "Unsupported image type for: $source\n";
						return;
				}				
		}

	}

	new Optimize();